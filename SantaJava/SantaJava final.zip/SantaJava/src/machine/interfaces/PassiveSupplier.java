package machine.interfaces;

import machine.components.passive.Present;

public interface PassiveSupplier {

    Present supply();

}
