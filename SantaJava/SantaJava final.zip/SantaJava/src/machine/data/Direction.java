package machine.data;

public enum Direction {
    N,
    E,
    S,
    W
}